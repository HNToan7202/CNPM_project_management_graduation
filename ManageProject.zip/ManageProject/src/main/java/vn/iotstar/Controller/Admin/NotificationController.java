package vn.iotstar.Controller.Admin;

import org.springframework.web.bind.annotation.GetMapping;

public class NotificationController {

	//
	//tạo thông báo
	// xóa thông báo
	// xem thông báo
	
}

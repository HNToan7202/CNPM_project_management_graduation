package vn.iotstar.Utils;

public class Constant {
	public static final String SESION_USERNAME ="username";
	public static final String COOKIE_REMEMBER ="username";
	public static final String DIR = "D:\\Download\\Spring\\Sprint-1\\ManageProject\\src\\main\\webapp\\resources\\images";
	public static class Path {
		public static final String LOGIN ="/views/common/login.jsp";
		public static final String REGISTER ="/views/common/register.jsp";
		public static final String HOME ="/views/user/index.jsp";
		public static final String DASHBOARD ="/views/admin/index.jsp";
		public static final String MYACCOUNT ="/views/user/myaccount.jsp";
	}

}

